requirejs.config({
  baseUrl: './js',
  urlArgs: "cached=" + ((new Date()).getTime()).toString().substr(-5),
  urlArgs: "v=" + 1,
  waitSeconds: 15,

  paths: {
    // jquery
    'jquery': 'lib/jquery.min.js',
    // bootstrap
    'bootstrap': 'lib/plugins/bootstrap.min',
    // old browsers scripts under Internet Explorer 10
    'oldBrowsers': 'lib/plugins/old-browsers.js'
  },

  shim: {
    'bootstrap': {
      deps: ['jquery']
    }
  }

});

require(['bootstrap'], function(bootstrap) {
  $('[data-toggle="tooltip"]').tooltip();
  $('[data-toggle="popover"]').popover();
});
