requirejs.config({
  baseUrl: './js',

  paths: {
    // jquery
    'jquery': [
      'lib/jquery.min',
      '//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min',
    ],
    // bootstrap
    'bootstrap': [
      'lib/plugins/bootstrap.min',
      '//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min',
    ],
    // old browsers script under Internet Explorer 10
    'oldBrowsers': [
      'lib/plugins/old-browsers.js',
    ]

  },

  shim: {
    'bootstrap': {
      deps: ['jquery'],
      exports: "bootstrap"
    },
  }

});

require(['bootstrap'], function(bootstrap) {
  $('[data-toggle="tooltip"]').tooltip();
  $('[data-toggle="popover"]').popover();
});